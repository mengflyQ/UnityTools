﻿using UnityEngine;

namespace libx
{
    public class ObjectHolder : MonoBehaviour
    {
        public Object[] objects;
    }
} 